discord_url = "https://discord.com/api/webhooks/1113812481593315411/3Z8NzuiGsN2RC5AbE9wyvtQrn0edzguNPJPIaIG1iqKi3WbyxXR_TIhAmzI_cI5oCrGY"
# add your discord webhook to the variable.
