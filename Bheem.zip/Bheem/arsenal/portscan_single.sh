#!/bin/sh

dir=~/Recon/$1

naabu $1 > $dir/$1_portscan;

