#!/bin/sh

dir=~/Recon/$1

naabu -l $dir/$1_subdomains > $dir/$1_portscan;

