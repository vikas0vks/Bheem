#!/bin/sh

dir=~/Recon/$1

#SubOver -l $dir/$1_subdomains -o $dir/$1_takeover;
subzy --targets $dir/$1_subdomains run
