#!/bin/sh

dir=~/Recon/$1

dalfox -b vikasvks.bxss.in file $dir/$1_params > $dir/$1_xss;
